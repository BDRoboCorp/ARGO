/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./DateAsCheckbox/index.ts":
/*!*********************************!*\
  !*** ./DateAsCheckbox/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DateAsCheckbox: () => (/* binding */ DateAsCheckbox)\n/* harmony export */ });\nclass DateAsCheckbox {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  init(context, notifyOutputChanged, state, container) {\n    var id = Math.random().toString().split('.')[1];\n    this._checkboxid = id + \"-c\";\n    this._labelid = id + \"-l\";\n    // @ts-expect-error not exposed by the framework\n    this._options = context.parameters.DateAttribute.attributes.Options;\n    this._notifyOutputChanged = notifyOutputChanged;\n    var subContainer = document.createElement(\"div\");\n    subContainer.className = \"dac-container\";\n    container.appendChild(subContainer);\n    var lblContainer = document.createElement(\"label\");\n    lblContainer.setAttribute(\"class\", \"dac-container-switch\");\n    subContainer.appendChild(lblContainer);\n    var chk = document.createElement(\"input\");\n    chk.id = this._checkboxid;\n    chk.setAttribute(\"type\", \"checkbox\");\n    chk.addEventListener(\"change\", this.changefunction);\n    if (context.mode.isControlDisabled) {\n      chk.setAttribute(\"disabled\", \"disabled\");\n    }\n    var toggle = document.createElement(\"span\");\n    lblContainer.appendChild(chk);\n    lblContainer.appendChild(toggle);\n    if (context.parameters.offColor && context.parameters.offColor.raw) {\n      this.createStyleRule(\".dac-slider-\" + this._checkboxid, \"{background-color:\" + context.parameters.offColor.raw + \" !important;border:solid 2px \" + context.parameters.offColor.raw + \" !important;}\");\n    }\n    if (context.parameters.onColor && context.parameters.onColor.raw) {\n      this.createStyleRule(\"input:checked + .dac-slider-\" + this._checkboxid, \"{background-color:\" + context.parameters.onColor.raw + \" !important;border:solid 2px \" + context.parameters.onColor.raw + \" !important;}\");\n    }\n    if (context.parameters.switchColor && context.parameters.switchColor.raw) {\n      this.createStyleRule(\".dac-slider-\" + this._checkboxid + \"::before\", \"{background-color:\" + context.parameters.switchColor.raw + \" !important;}\");\n    }\n    if (context.parameters.layout && context.parameters.layout.raw === \"Square\") {\n      toggle.setAttribute(\"class\", \"dac-slider-default dac-slider-\" + this._checkboxid);\n    } else {\n      toggle.setAttribute(\"class\", \"dac-slider-default dac-slider-\" + this._checkboxid + \" dac-round\");\n    }\n  }\n  changefunction() {\n    this._notifyOutputChanged();\n  }\n  createStyleRule(name, content) {\n    var styleSheet = this.GetStyleSheet();\n    if (styleSheet != null) {\n      styleSheet.insertRule(name + \" \" + content);\n    }\n  }\n  GetStyleSheet() {\n    for (var i = 0; i < document.styleSheets.length; i++) {\n      var sheet = document.styleSheets[i];\n      if (sheet.href && sheet.href.endsWith(\"CustomSwitch.css\")) {\n        return sheet;\n      }\n    }\n    return null;\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  updateView(context) {\n    if (context.parameters.DateAttribute) {\n      document.getElementById(this._checkboxid).checked = context.parameters.DateAttribute.raw != null && context.parameters.DateAttribute.raw != undefined;\n    }\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  getOutputs() {\n    var date;\n    date = new Date();\n    if (document.getElementById(this._checkboxid).checked === false) {\n      date = undefined;\n    }\n    return {\n      DateAttribute: date\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./DateAsCheckbox/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./DateAsCheckbox/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MscrmTools.DateAsCheckbox', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DateAsCheckbox);
} else {
	var MscrmTools = MscrmTools || {};
	MscrmTools.DateAsCheckbox = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.DateAsCheckbox;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}