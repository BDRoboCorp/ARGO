/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./LinearSliderWithSteps/index.ts":
/*!****************************************!*\
  !*** ./LinearSliderWithSteps/index.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   LinearSliderWithSteps: () => (/* binding */ LinearSliderWithSteps)\n/* harmony export */ });\nclass LinearSliderWithSteps {\n  /**\r\n   * Empty constructor.\r\n   */\n  constructor() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n  init(context, notifyOutputChanged, state, container) {\n    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;\n    var id = Math.random().toString().split('.')[1];\n    this._context = context;\n    this._container = document.createElement(\"div\");\n    this._container.style.textAlign = context.parameters.labelPosition.raw;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._refreshData = this.refreshData.bind(this);\n    // creating HTML elements for the input type range and binding it to the function which refreshes the control data\n    this.inputElement = document.createElement(\"input\");\n    this.inputElement.setAttribute(\"type\", \"range\");\n    this.inputElement.addEventListener(\"input\", this._refreshData);\n    if (context.mode.isControlDisabled) {\n      this.inputElement.setAttribute(\"disabled\", \"disabled\");\n    }\n    //setting the max and min values for the control.\n    this.inputElement.setAttribute(\"min\", (_b = (_a = context.parameters.min.raw) === null || _a === void 0 ? void 0 : _a.toString()) !== null && _b !== void 0 ? _b : \"0\");\n    this.inputElement.setAttribute(\"max\", (_d = (_c = context.parameters.max.raw) === null || _c === void 0 ? void 0 : _c.toString()) !== null && _d !== void 0 ? _d : \"100\");\n    this.inputElement.setAttribute(\"step\", (_f = (_e = context.parameters.step.raw) === null || _e === void 0 ? void 0 : _e.toString()) !== null && _f !== void 0 ? _f : \"1\");\n    this.inputElement.setAttribute(\"class\", \"linearslider\");\n    this.inputElement.setAttribute(\"id\", \"linearrangeinput-\" + id);\n    if (context.parameters.color && context.parameters.color.raw) {\n      if (navigator.userAgent.indexOf(\"Chrome\") >= 0) {\n        this.createStyleRule(\".LinerSliderWithSteps-\" + id + \"::-webkit-slider-runnable-track\", \"{background-color:\" + context.parameters.color.raw + \" !important;}\");\n        this.createStyleRule(\".LinerSliderWithSteps-\" + id + \"::-webkit-slider-thumb\", \"{background-color:\" + context.parameters.color.raw + \" !important;}\");\n      } else if (navigator.userAgent.indexOf(\"Firefox\") >= 0) {\n        this.createStyleRule(\".LinerSliderWithSteps-\" + id + \"::-moz-range-track\", \"{background-color:\" + context.parameters.color.raw + \" !important;}\");\n        this.createStyleRule(\".LinerSliderWithSteps-\" + id + \"::-moz-range-thumb\", \"{background-color:\" + context.parameters.color.raw + \" !important;}\");\n      } else if (navigator.userAgent.indexOf(\"Edge\") >= 0) {\n        this.createStyleRule(\".LinerSliderWithSteps-\" + id + \"::-ms-track\", \"{background-color:\" + context.parameters.color.raw + \" !important;}\");\n        this.createStyleRule(\".LinerSliderWithSteps-\" + id + \"::-ms-thumb\", \"{background-color:\" + context.parameters.color.raw + \" !important;}\");\n      }\n      this.inputElement.setAttribute(\"class\", \"linearslider LinerSliderWithSteps-\" + id);\n    } else {\n      this.inputElement.setAttribute(\"class\", \"linearslider\");\n    }\n    // creating a HTML label element that shows the value that is set on the linear range control\n    this.labelElement = document.createElement(\"label\");\n    this.labelElement.setAttribute(\"class\", \"TS_LinearRangeLabel\");\n    this.labelElement.setAttribute(\"id\", \"lrclabel-\" + id);\n    // retrieving the latest value from the control and setting it to the HTMl elements.\n    this._value = context.parameters.controlValue.raw;\n    this.inputElement.setAttribute(\"value\", context.parameters.controlValue.formatted ? context.parameters.controlValue.formatted : (_h = (_g = context.parameters.min.raw) === null || _g === void 0 ? void 0 : _g.toString()) !== null && _h !== void 0 ? _h : \"0\");\n    this.labelElement.innerHTML = (_o = ((_j = context.parameters.labelPrefix.raw) !== null && _j !== void 0 ? _j : \"\") + \" \" + context.parameters.controlValue.formatted ? context.parameters.controlValue.formatted : (_l = (_k = context.parameters.min.raw) === null || _k === void 0 ? void 0 : _k.toString()) !== null && _l !== void 0 ? _l : 0 + \" \" + ((_m = context.parameters.labelSuffix.raw) !== null && _m !== void 0 ? _m : \"\")) !== null && _o !== void 0 ? _o : \"\";\n    // appending the HTML elements to the control's HTML container element.\n    this._container.appendChild(this.inputElement);\n    this._container.appendChild(this.labelElement);\n    container.appendChild(this._container);\n  }\n  createStyleRule(name, content) {\n    var styleSheet = this.GetStyleSheet();\n    if (styleSheet != null) {\n      styleSheet.insertRule(name + \" \" + content);\n    }\n  }\n  GetStyleSheet() {\n    for (var i = 0; i < document.styleSheets.length; i++) {\n      var sheet = document.styleSheets[i];\n      if (sheet.href && sheet.href.endsWith(\"LinearSliderWithSteps.css\")) {\n        return sheet;\n      }\n    }\n    return null;\n  }\n  /**\r\n   * Updates the values to the internal value variable we are storing and also updates the html label that displays the value\r\n   * @param evt : The \"Input Properties\" containing the parameters, control metadata and interface functions\r\n   */\n  refreshData() {\n    var _a, _b;\n    this._value = parseInt(this.inputElement.value);\n    this.labelElement.innerHTML = ((_a = this._context.parameters.labelPrefix.raw) !== null && _a !== void 0 ? _a : \"\") + \" \" + this.inputElement.value + \" \" + ((_b = this._context.parameters.labelSuffix.raw) !== null && _b !== void 0 ? _b : \"\");\n    this._notifyOutputChanged();\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  updateView(context) {\n    var _a, _b;\n    if (context.mode.isControlDisabled) {\n      this.inputElement.setAttribute(\"disabled\", \"disabled\");\n    } else {\n      this.inputElement.removeAttribute(\"disabled\");\n    }\n    // storing the latest context from the control.\n    this._value = context.parameters.controlValue.raw;\n    this._context = context;\n    this.inputElement.setAttribute(\"value\", context.parameters.controlValue.formatted ? context.parameters.controlValue.formatted : \"\");\n    this.labelElement.innerHTML = ((_a = this._context.parameters.labelPrefix.raw) !== null && _a !== void 0 ? _a : \"\") + \" \" + this.inputElement.value + \" \" + ((_b = this._context.parameters.labelSuffix.raw) !== null && _b !== void 0 ? _b : \"\");\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  getOutputs() {\n    return {\n      controlValue: this._value\n    };\n  }\n  /**\r\n    * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    this.inputElement.removeEventListener(\"input\", this._refreshData);\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./LinearSliderWithSteps/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./LinearSliderWithSteps/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MscrmTools.LinearSliderWithSteps', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LinearSliderWithSteps);
} else {
	var MscrmTools = MscrmTools || {};
	MscrmTools.LinearSliderWithSteps = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.LinearSliderWithSteps;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}